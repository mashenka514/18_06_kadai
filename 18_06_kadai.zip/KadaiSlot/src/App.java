import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.Random;

public class App extends Application{
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage stage) throws Exception{
        //スロットに表示する配列
        String[] number_array1 = {"1","2","3","4","5","6","7","8","9"};
        String[] number_array2 = {"1","2","3","4","5","6","7","8","9"};
        String[] number_array3 = {"1","2","3","4","5","6","7","8","9"};
        //スロットの表示
        Label number1 = new Label("1");
        Label number2 = new Label("1");
        Label number3 = new Label("1");

        HBox hBox1 = new HBox(20d);
        hBox1.setAlignment(Pos.CENTER);

        hBox1.getChildren().add(number1);
        hBox1.getChildren().add(number2);
        hBox1.getChildren().add(number3);
        //Startボタン
        Button start_button = new Button("START!!");
        //Startボタンのアクション
        start_button.setOnAction(event -> {
            Random rand = new Random();
            Timeline timer = new Timeline(new KeyFrame(Duration.millis(100), e -> {
                int randomNumber1 = rand.nextInt(number_array1.length);
                int randomNumber2 = rand.nextInt(number_array2.length);
                int randomNumber3 = rand.nextInt(number_array3.length);
                number1.setText(number_array1[randomNumber1]);
                number2.setText(number_array2[randomNumber2]);
                number3.setText(number_array3[randomNumber3]);
            }));
            timer.setCycleCount(30);
            timer.play();
            timer.stop();
        });
        //Stopボタンの作成
        Button stop_button = new Button("STOP!!");
        //Stopボタンのアクション
        /*ボタンを押したら,アニメーションを停止し、その時点でのランダムの配列が表示される*/
        stop_button.setOnAction(event -> {
            number1.
        });



        HBox hBox2 = new HBox(20d);
        hBox2.setAlignment(Pos.CENTER);
        hBox2.getChildren().add(start_button);
        hBox2.getChildren().add(stop_button);

        //BorderPaneとScene
        BorderPane borderPane = new BorderPane();
        borderPane.setPadding(new Insets(30,10,10,10));
        borderPane.setTop(hBox1);
        borderPane.setCenter(hBox2);

        Scene scene = new Scene(borderPane,320,240);
        stage.setScene(scene);
        stage.show();
    }

}
